"""Writes minimal WebArena-Verified logs (agent_response.json, network.har); see the issue text."""

import json
import pathlib
import urllib.parse


def entry(method, url, status, page=False, form=None, body=None, headers=None, reply=None):
    """One HAR entry: a top-level page load if page=True, otherwise a background request."""
    h = {"Accept": "text/html,application/xhtml+xml", "Sec-Fetch-Dest": "document",
         "Sec-Fetch-Mode": "navigate", "Sec-Fetch-User": "?1"} if page else {
         "Accept": "application/json, text/javascript, */*; q=0.01", "X-Requested-With": "XMLHttpRequest"}
    h.update(headers or {})
    request = {"method": method, "url": url, "headers": [{"name": k, "value": v} for k, v in h.items()]}
    if form is not None:
        request["postData"] = {"mimeType": "application/x-www-form-urlencoded", "text": urllib.parse.urlencode(form)}
    if body is not None:
        request["postData"] = {"mimeType": "application/json", "text": json.dumps(body)}
    content = {"mimeType": "application/json", "text": json.dumps(reply)} if reply is not None else {"mimeType": "text/html"}
    return {"request": request,
            "response": {"status": status, "headers": [], "cookies": [], "content": content, "redirectURL": ""}}


def write(out, task_id, task_type, status, entries, retrieved_data=None):
    folder = pathlib.Path(out, str(task_id))
    folder.mkdir(parents=True, exist_ok=True)
    response = {"task_type": task_type, "status": status, "retrieved_data": retrieved_data, "error_details": None}
    (folder / "agent_response.json").write_text(json.dumps(response, indent=2))
    (folder / "network.har").write_text(json.dumps({"log": {"entries": entries}}, indent=1))


SHOP = "http://localhost:7770"
REDDIT = "http://localhost:9999"
GITLAB = "http://localhost:8023"


def post(repo, body):
    return entry("POST", REDDIT + "/submit/MachineLearning", 302, form={
        "submission[mediaType]": "url", "submission[url]": f"{GITLAB}/{repo}", "submission[title]": repo,
        "submission[body]": body, "submission[forum]": "10018"})


# 148 "Get the color of the picture frame I bought Sep 2022": our runs answered the color, Mist
write("out", 148, "RETRIEVE", "SUCCESS", [entry("GET", SHOP + "/sales/order/history/", 200, page=True)],
      retrieved_data=["Mist"])
# 682: convexegg/chatgpt, posted with its real commit count (the repository page shows "1 Commit")
write("out", 682, "MUTATE", "SUCCESS", [post("convexegg/chatgpt", "1 commit already!")])
# 683: root/metaseq (272 commits), the metaseq repository the site has; body as the reference writes it
write("out", 683, "MUTATE", "SUCCESS", [post("root/metaseq", "272 commits already!")])
