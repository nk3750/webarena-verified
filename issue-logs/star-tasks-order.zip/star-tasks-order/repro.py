"""Writes minimal WebArena-Verified logs (agent_response.json, network.har); see the issue text."""

import json
import pathlib
import urllib.parse


def entry(method, url, status, page=False, form=None, body=None, headers=None, reply=None):
    """One HAR entry: a top-level page load if page=True, otherwise a background request."""
    h = {"Accept": "text/html,application/xhtml+xml", "Sec-Fetch-Dest": "document",
         "Sec-Fetch-Mode": "navigate", "Sec-Fetch-User": "?1"} if page else {
         "Accept": "application/json, text/javascript, */*; q=0.01", "X-Requested-With": "XMLHttpRequest"}
    h.update(headers or {})
    request = {"method": method, "url": url, "headers": [{"name": k, "value": v} for k, v in h.items()]}
    if form is not None:
        request["postData"] = {"mimeType": "application/x-www-form-urlencoded", "text": urllib.parse.urlencode(form)}
    if body is not None:
        request["postData"] = {"mimeType": "application/json", "text": json.dumps(body)}
    content = {"mimeType": "application/json", "text": json.dumps(reply)} if reply is not None else {"mimeType": "text/html"}
    return {"request": request,
            "response": {"status": status, "headers": [], "cookies": [], "content": content, "redirectURL": ""}}


def write(out, task_id, task_type, status, entries, retrieved_data=None):
    folder = pathlib.Path(out, str(task_id))
    folder.mkdir(parents=True, exist_ok=True)
    response = {"task_type": task_type, "status": status, "retrieved_data": retrieved_data, "error_details": None}
    (folder / "agent_response.json").write_text(json.dumps(response, indent=2))
    (folder / "network.har").write_text(json.dumps({"log": {"entries": entries}}, indent=1))


GITLAB = "http://localhost:8023"
REPOS = [("umano/AndroidSlidingUpPanel", 56), ("facebook/create-react-app", 53), ("kkroening/ffmpeg-python", 52)]

# Task 526 "Star the top three most stared repos in Gitlab", run after task 523 (top five) on the same GitLab:
# the three repositories already show "Unstar", so a correct run sends nothing
pages = [entry("GET", f"{GITLAB}/{repo}", 200, page=True) for repo, _ in REPOS]
write("out-after-523", 526, "MUTATE", "SUCCESS", pages)

# Contrast: unstar then star again; the second toggle answers the star count the check expects
toggles = []
for repo, stars in REPOS:
    toggles.append(entry("POST", f"{GITLAB}/{repo}/toggle_star.json", 200, reply={"star_count": stars - 1}))
    toggles.append(entry("POST", f"{GITLAB}/{repo}/toggle_star.json", 200, reply={"star_count": stars}))
write("out-unstar-restar", 526, "MUTATE", "SUCCESS", pages + toggles)
