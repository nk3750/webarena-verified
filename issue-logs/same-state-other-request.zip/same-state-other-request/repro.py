"""Writes minimal WebArena-Verified logs (agent_response.json, network.har); see the issue text."""

import json
import pathlib
import urllib.parse


def entry(method, url, status, page=False, form=None, body=None, headers=None, reply=None):
    """One HAR entry: a top-level page load if page=True, otherwise a background request."""
    h = {"Accept": "text/html,application/xhtml+xml", "Sec-Fetch-Dest": "document",
         "Sec-Fetch-Mode": "navigate", "Sec-Fetch-User": "?1"} if page else {
         "Accept": "application/json, text/javascript, */*; q=0.01", "X-Requested-With": "XMLHttpRequest"}
    h.update(headers or {})
    request = {"method": method, "url": url, "headers": [{"name": k, "value": v} for k, v in h.items()]}
    if form is not None:
        request["postData"] = {"mimeType": "application/x-www-form-urlencoded", "text": urllib.parse.urlencode(form)}
    if body is not None:
        request["postData"] = {"mimeType": "application/json", "text": json.dumps(body)}
    content = {"mimeType": "application/json", "text": json.dumps(reply)} if reply is not None else {"mimeType": "text/html"}
    return {"request": request,
            "response": {"status": status, "headers": [], "cookies": [], "content": content, "redirectURL": ""}}


def write(out, task_id, task_type, status, entries, retrieved_data=None):
    folder = pathlib.Path(out, str(task_id))
    folder.mkdir(parents=True, exist_ok=True)
    response = {"task_type": task_type, "status": status, "retrieved_data": retrieved_data, "error_details": None}
    (folder / "agent_response.json").write_text(json.dumps(response, indent=2))
    (folder / "network.har").write_text(json.dumps({"log": {"entries": entries}}, indent=1))


ADMIN = "http://localhost:7780/admin"
GITLAB = "http://localhost:8023"

# 502 "Mark all Gobi HeatTec Tee as out of stock": grid search "Gobi HeatTec", all 16 rows selected
# (configurable 446 and its 15 variants), mass action "Update attributes", Stock Availability = Out of Stock
write("out", 502, "MUTATE", "SUCCESS", [
    entry("POST", ADMIN + "/catalog/product_action_attribute/save/store/0/", 302, form={"inventory[is_in_stock]": "0"})])

# 774 "Delete all pending reviews with less than 4 stars" and 776 "Delete all reviews from the scammer Carlo":
# exactly the expected reviews, deleted with the grid's mass action
write("out", 774, "MUTATE", "SUCCESS", [
    entry("POST", ADMIN + "/review/product/massDelete/ret/index/", 302,
          form={"reviews": "353,351,349", "massaction_prepare_key": "reviews"})])
write("out", 776, "MUTATE", "SUCCESS", [
    entry("POST", ADMIN + "/review/product/massDelete/ret/index/", 302,
          form={"reviews": "109,93", "massaction_prepare_key": "reviews"})])


def invite(project, access_level, user_id):
    return entry("POST", f"{GITLAB}/api/v4/projects/{project}/invitations", 201,
                 body={"format": "json", "access_level": access_level, "invite_source": "project-members-page",
                       "tasks_to_be_done": [], "tasks_project_id": "", "user_id": user_id})


# 577 and 578 "Add the following users ... as maintainer / reporter": one invitation per user, both 201
write("out", 577, "MUTATE", "SUCCESS", [invite(181, 40, "5"), invite(181, 40, "1842")])
write("out", 578, "MUTATE", "SUCCESS", [invite(187, 20, "168"), invite(187, 20, "2325")])

# 488 "Change the page title of 'Home Page' ...": the CMS pages grid's inline editor
write("out", 488, "MUTATE", "SUCCESS", [
    entry("POST", ADMIN + "/cms/page/inlineEdit/?isAjax=true", 200, form={
        "items[2][title]": "This is the home page!! Leave here!!", "items[2][identifier]": "home",
        "items[2][page_layout]": "1column", "items[2][is_active]": "1", "items[2][page_id]": "2"})])

# 416 "Reply on the merge request assigned to me for wcag ...": "Reply to comment" on the author's last comment
write("out", 416, "MUTATE", "SUCCESS", [
    entry("POST", GITLAB + "/a11yproject/a11yproject.com/notes?target_id=72409&target_type=merge_request", 200,
          body={"in_reply_to_discussion_id": "5afe9b9b15bc67381eef5824842b475a157fae22",
                "target_type": "merge_request", "note": {"note": "Thank you"}, "return_discussion": True})])

# Contrast: the request shapes the checks expect (one delete per review; one invitation for both users)
write("out-expected-shape", 776, "MUTATE", "SUCCESS", [
    entry("POST", ADMIN + "/review/product/delete/id/109/", 302), entry("POST", ADMIN + "/review/product/delete/id/93/", 302)])
write("out-expected-shape", 578, "MUTATE", "SUCCESS", [invite(187, 20, "168,2325")])
# 578 also fails one invitation that lists the two users in the other order (577's check has a string_list schema)
write("out-other-order", 578, "MUTATE", "SUCCESS", [invite(187, 20, "2325,168")])
