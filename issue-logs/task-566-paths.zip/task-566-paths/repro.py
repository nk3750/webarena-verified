"""Writes minimal WebArena-Verified logs (agent_response.json, network.har); see the issue text."""

import json
import pathlib
import urllib.parse


def entry(method, url, status, page=False, form=None, body=None, headers=None, reply=None):
    """One HAR entry: a top-level page load if page=True, otherwise a background request."""
    h = {"Accept": "text/html,application/xhtml+xml", "Sec-Fetch-Dest": "document",
         "Sec-Fetch-Mode": "navigate", "Sec-Fetch-User": "?1"} if page else {
         "Accept": "application/json, text/javascript, */*; q=0.01", "X-Requested-With": "XMLHttpRequest"}
    h.update(headers or {})
    request = {"method": method, "url": url, "headers": [{"name": k, "value": v} for k, v in h.items()]}
    if form is not None:
        request["postData"] = {"mimeType": "application/x-www-form-urlencoded", "text": urllib.parse.urlencode(form)}
    if body is not None:
        request["postData"] = {"mimeType": "application/json", "text": json.dumps(body)}
    content = {"mimeType": "application/json", "text": json.dumps(reply)} if reply is not None else {"mimeType": "text/html"}
    return {"request": request,
            "response": {"status": status, "headers": [], "cookies": [], "content": content, "redirectURL": ""}}


def write(out, task_id, task_type, status, entries, retrieved_data=None):
    folder = pathlib.Path(out, str(task_id))
    folder.mkdir(parents=True, exist_ok=True)
    response = {"task_type": task_type, "status": status, "retrieved_data": retrieved_data, "error_details": None}
    (folder / "agent_response.json").write_text(json.dumps(response, indent=2))
    (folder / "network.har").write_text(json.dumps({"log": {"entries": entries}}, indent=1))


GITLAB = "http://localhost:8023"
POSTS = [
    ("Separate glued plastic parts", "118903/separate-glued-plastic-parts"),
    ("How would you fix this dryer vent mess?", "118923/how-would-you-fix-this-dryer-vent-mess"),
    ("Basement Bulkhead/Soffit + Wall Framing", "118935/basement-bulkhead-soffit-wall-framing"),
    ("GE Water Heater Pilot Light Won't Stay Lit", "118904/ge-water-heater-pilot-light-won-t-stay-lit"),
    ("Attempting to move a wall outlet in my basement a few inches to the left and am totally stumped. "
     "Any help GREATLY appreciated!!", "118960/attempting-to-move-a-wall-outlet-in-my-basement-a-few-inches"),
    ("AFCI Outlet Question", "118931/afci-outlet-question"),
    ("Teflon tape to attach washing machine drain hose to pipe?",
     "118824/teflon-tape-to-attach-washing-machine-drain-hose-to-pipe"),
    ("Paver base for shed?", "118866/paver-base-for-shed"),
]
# The README exactly as the commit check expects it (copied from the dataset), so that only the path differs
README = "# Do it myself\n\n## Most Active DIY Threads\n\n" + "\n".join(
    f"- [{title}](__REDDIT__/f/DIY/{path})" for title, path in POSTS)

# One repository named "Do it myself", created and then committed to, under each of the two paths
for path in ("do-it-myself", "do-it-myself-with"):
    create = entry("POST", GITLAB + "/projects", 302, form={
        "project[name]": "Do it myself", "project[path]": path, "project[namespace_id]": "2505",
        "project[visibility_level]": "0", "project[initialize_with_readme]": "1"})
    commit = entry("POST", f"{GITLAB}/api/v4/projects/byteblaze%2F{path}/repository/commits", 201, body={
        "branch": "main", "commit_message": "Update README.md",
        "actions": [{"action": "update", "file_path": "README.md", "content": README, "encoding": "text"}]})
    write(f"out-{path}", 566, "MUTATE", "SUCCESS", [create, commit])
