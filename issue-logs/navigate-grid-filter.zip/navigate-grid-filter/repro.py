"""Writes minimal WebArena-Verified logs (agent_response.json, network.har); see the issue text."""

import json
import pathlib
import urllib.parse


def entry(method, url, status, page=False, form=None, body=None, headers=None, reply=None):
    """One HAR entry: a top-level page load if page=True, otherwise a background request."""
    h = {"Accept": "text/html,application/xhtml+xml", "Sec-Fetch-Dest": "document",
         "Sec-Fetch-Mode": "navigate", "Sec-Fetch-User": "?1"} if page else {
         "Accept": "application/json, text/javascript, */*; q=0.01", "X-Requested-With": "XMLHttpRequest"}
    h.update(headers or {})
    request = {"method": method, "url": url, "headers": [{"name": k, "value": v} for k, v in h.items()]}
    if form is not None:
        request["postData"] = {"mimeType": "application/x-www-form-urlencoded", "text": urllib.parse.urlencode(form)}
    if body is not None:
        request["postData"] = {"mimeType": "application/json", "text": json.dumps(body)}
    content = {"mimeType": "application/json", "text": json.dumps(reply)} if reply is not None else {"mimeType": "text/html"}
    return {"request": request,
            "response": {"status": status, "headers": [], "cookies": [], "content": content, "redirectURL": ""}}


def write(out, task_id, task_type, status, entries, retrieved_data=None):
    folder = pathlib.Path(out, str(task_id))
    folder.mkdir(parents=True, exist_ok=True)
    response = {"task_type": task_type, "status": status, "retrieved_data": retrieved_data, "error_details": None}
    (folder / "agent_response.json").write_text(json.dumps(response, indent=2))
    (folder / "network.har").write_text(json.dumps({"log": {"entries": entries}}, indent=1))


# Task 679, "Go to the list of orders that are completed": what the browser sent in our run
ADMIN = "http://localhost:7780/admin"
GRID = ADMIN + "/mui/index/render/?namespace=sales_order_grid&search=&keywordUpdated=false&filters%5Bplaceholder%5D=true"
SORT = "&paging%5BpageSize%5D=200&paging%5Bcurrent%5D=1&sorting%5Bfield%5D=created_at&sorting%5Bdirection%5D=desc&isAjax=true"
COMPLETE = GRID + "&filters%5Bstatus%5D=complete" + SORT
orders_page = entry("GET", ADMIN + "/sales/order/", 200, page=True)
grid_all = entry("GET", GRID + SORT, 200, headers={"Referer": ADMIN + "/sales/order/"})
grid_complete = entry("GET", COMPLETE, 200, headers={"Referer": ADMIN + "/sales/order/"})
write("out-ui", 679, "NAVIGATE", "SUCCESS", [orders_page, grid_all, grid_complete])

# Not from a browser: the filter request typed into the address bar (a page load with no referer)
write("out-typed", 679, "NAVIGATE", "SUCCESS", [orders_page, grid_all, entry("GET", COMPLETE, 200, page=True)])

# Not from a browser: the filter request recorded as a page load with the Orders page as its referer
write("out-as-page", 679, "NAVIGATE", "SUCCESS", [orders_page, grid_all,
      entry("GET", COMPLETE, 200, page=True, headers={"Referer": ADMIN + "/sales/order/"})])
