"""Writes minimal WebArena-Verified logs (agent_response.json, network.har); see the issue text."""

import json
import pathlib
import urllib.parse


def entry(method, url, status, page=False, form=None, body=None, headers=None, reply=None):
    """One HAR entry: a top-level page load if page=True, otherwise a background request."""
    h = {"Accept": "text/html,application/xhtml+xml", "Sec-Fetch-Dest": "document",
         "Sec-Fetch-Mode": "navigate", "Sec-Fetch-User": "?1"} if page else {
         "Accept": "application/json, text/javascript, */*; q=0.01", "X-Requested-With": "XMLHttpRequest"}
    h.update(headers or {})
    request = {"method": method, "url": url, "headers": [{"name": k, "value": v} for k, v in h.items()]}
    if form is not None:
        request["postData"] = {"mimeType": "application/x-www-form-urlencoded", "text": urllib.parse.urlencode(form)}
    if body is not None:
        request["postData"] = {"mimeType": "application/json", "text": json.dumps(body)}
    content = {"mimeType": "application/json", "text": json.dumps(reply)} if reply is not None else {"mimeType": "text/html"}
    return {"request": request,
            "response": {"status": status, "headers": [], "cookies": [], "content": content, "redirectURL": ""}}


def write(out, task_id, task_type, status, entries, retrieved_data=None):
    folder = pathlib.Path(out, str(task_id))
    folder.mkdir(parents=True, exist_ok=True)
    response = {"task_type": task_type, "status": status, "retrieved_data": retrieved_data, "error_details": None}
    (folder / "agent_response.json").write_text(json.dumps(response, indent=2))
    (folder / "network.har").write_text(json.dumps({"log": {"entries": entries}}, indent=1))


ADMIN = "http://localhost:7780/admin"

# Task 493: the expected request, sent twice in our run; each time the page showed the alert
# "We cannot add order history." and no comment was added
comment = entry("POST", ADMIN + "/sales/order/addComment/order_id/65/?isAjax=true", 200, form={
    "history[comment]": "sorry we are bankrupt, please contact our customer service for refund",
    "history[is_customer_notified]": "1"})
write("out-honest", 493, "MUTATE", "UNKNOWN_ERROR", [comment, comment])
# The same log with a claim of success
write("out-claimed", 493, "MUTATE", "SUCCESS", [comment, comment])
