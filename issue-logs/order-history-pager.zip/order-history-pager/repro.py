"""Writes minimal WebArena-Verified logs (agent_response.json, network.har); see the issue text."""

import json
import pathlib
import urllib.parse


def entry(method, url, status, page=False, form=None, body=None, headers=None, reply=None):
    """One HAR entry: a top-level page load if page=True, otherwise a background request."""
    h = {"Accept": "text/html,application/xhtml+xml", "Sec-Fetch-Dest": "document",
         "Sec-Fetch-Mode": "navigate", "Sec-Fetch-User": "?1"} if page else {
         "Accept": "application/json, text/javascript, */*; q=0.01", "X-Requested-With": "XMLHttpRequest"}
    h.update(headers or {})
    request = {"method": method, "url": url, "headers": [{"name": k, "value": v} for k, v in h.items()]}
    if form is not None:
        request["postData"] = {"mimeType": "application/x-www-form-urlencoded", "text": urllib.parse.urlencode(form)}
    if body is not None:
        request["postData"] = {"mimeType": "application/json", "text": json.dumps(body)}
    content = {"mimeType": "application/json", "text": json.dumps(reply)} if reply is not None else {"mimeType": "text/html"}
    return {"request": request,
            "response": {"status": status, "headers": [], "cookies": [], "content": content, "redirectURL": ""}}


def write(out, task_id, task_type, status, entries, retrieved_data=None):
    folder = pathlib.Path(out, str(task_id))
    folder.mkdir(parents=True, exist_ok=True)
    response = {"task_type": task_type, "status": status, "retrieved_data": retrieved_data, "error_details": None}
    (folder / "agent_response.json").write_text(json.dumps(response, indent=2))
    (folder / "network.har").write_text(json.dumps({"log": {"entries": entries}}, indent=1))


SHOP = "http://localhost:7770"

# Task 797 "Change the delivery address for my first order ever ...": 38 orders, 10 a page, newest first, so the
# first order is on page 4. The last six page loads of our run, which answered ACTION_NOT_ALLOWED_ERROR (expected)
loads = [entry("GET", SHOP + path, 200, page=True) for path in [
    "/customer/account/", "/sales/order/history/", "/sales/order/history/?p=4", "/sales/order/view/order_id/169/",
    "/sales/order/history/?p=4", "/sales/order/view/order_id/160/"]]
write("out-paged", 797, "MUTATE", "ACTION_NOT_ALLOWED_ERROR", loads)

# Contrast: the same run, ending with one more load of the first page of the history
write("out-back-to-page-1", 797, "MUTATE", "ACTION_NOT_ALLOWED_ERROR",
      loads + [entry("GET", SHOP + "/sales/order/history/", 200, page=True)])
